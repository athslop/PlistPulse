#import <UIKit/UIKit.h>

@interface PPMAppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;
@end
