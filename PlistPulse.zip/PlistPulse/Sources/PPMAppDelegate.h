#import <UIKit/UIKit.h>

@interface PPMAppDelegate : UIResponder <UIApplicationDelegate>
@end
