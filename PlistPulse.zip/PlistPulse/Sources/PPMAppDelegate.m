#import "PPMAppDelegate.h"
#import "PPMViewController.h"

@interface PPMAppDelegate ()
@property (nonatomic, strong) UIWindow *window;
@property (nonatomic, strong, nullable) NSURL *pendingURL;
@end

@implementation PPMAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:[PPMViewController new]];
    self.window.rootViewController = navigation;
    [self.window makeKeyAndVisible];
    if (self.pendingURL) {
        [(PPMViewController *)navigation.viewControllers.firstObject openPath:self.pendingURL.path];
        self.pendingURL = nil;
    }
    return YES;
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url
    options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options {
    if (!url.isFileURL) return NO;
    UINavigationController *navigation = (UINavigationController *)self.window.rootViewController;
    if (navigation == nil) {
        self.pendingURL = url;
        return YES;
    }
    PPMViewController *viewController = (PPMViewController *)navigation.viewControllers.firstObject;
    if (![viewController isKindOfClass:[PPMViewController class]]) return NO;
    [viewController openPath:url.path];
    return YES;
}

@end
