#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, PPMChangeKind) {
    PPMChangeKindAdded,
    PPMChangeKindRemoved,
    PPMChangeKindChanged,
};

@interface PPMChange : NSObject

@property (nonatomic, assign, readonly) PPMChangeKind kind;
@property (nonatomic, copy, readonly) NSString *keyPath;
@property (nonatomic, strong, readonly, nullable) id oldValue;
@property (nonatomic, strong, readonly, nullable) id updatedValue;
@property (nonatomic, strong, readonly) NSDate *date;

- (instancetype)initWithKind:(PPMChangeKind)kind
                    keyPath:(NSString *)keyPath
                   oldValue:(nullable id)oldValue
                   updatedValue:(nullable id)updatedValue
                       date:(NSDate *)date NS_DESIGNATED_INITIALIZER;
- (instancetype)init NS_UNAVAILABLE;

@end

NSString *PPMFormatValue(_Nullable id value);
NSString *PPMFormatKeyPath(NSString *keyPath);

NS_ASSUME_NONNULL_END
