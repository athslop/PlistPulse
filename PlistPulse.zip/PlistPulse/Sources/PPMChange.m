#import "PPMChange.h"
#include <CoreFoundation/CoreFoundation.h>
#include <string.h>

@implementation PPMChange

- (instancetype)initWithKind:(PPMChangeKind)kind
                    keyPath:(NSString *)keyPath
                   oldValue:(nullable id)oldValue
                   updatedValue:(nullable id)updatedValue
                       date:(NSDate *)date {
    self = [super init];
    if (self) {
        _kind = kind;
        _keyPath = [keyPath copy];
        _oldValue = oldValue;
        _updatedValue = updatedValue;
        _date = date ?: [NSDate date];
    }
    return self;
}

@end

static NSString *PPMFormatValueAtDepth(id value, NSUInteger depth);
static NSString *PPMIndent(NSUInteger depth) {
    return [@"" stringByPaddingToLength:depth * 2 withString:@" " startingAtIndex:0];
}

static NSString *PPMFormatValueAtDepth(id value, NSUInteger depth) {
    if (value == nil || value == (id)[NSNull null]) return @"nil";
    if (depth > 12) return @"…";

    if ([value isKindOfClass:[NSString class]]) {
        NSString *text = (NSString *)value;
        // Flutter preferences commonly store dictionaries/arrays as JSON strings.
        // Pretty-print those instead of showing one unreadable line.
        NSString *trimmed = [text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        if (trimmed.length > 1 &&
            (([trimmed hasPrefix:@"{"] && [trimmed hasSuffix:@"}"]) ||
             ([trimmed hasPrefix:@"["] && [trimmed hasSuffix:@"]"]))) {
            id parsed = [NSJSONSerialization JSONObjectWithData:[trimmed dataUsingEncoding:NSUTF8StringEncoding]
                options:NSJSONReadingFragmentsAllowed error:nil];
            if ([parsed isKindOfClass:[NSDictionary class]] || [parsed isKindOfClass:[NSArray class]]) {
                return PPMFormatValueAtDepth(parsed, depth);
            }
        }
        NSMutableString *escaped = [text mutableCopy];
        [escaped replaceOccurrencesOfString:@"\\" withString:@"\\\\" options:0 range:NSMakeRange(0, escaped.length)];
        [escaped replaceOccurrencesOfString:@"\n" withString:@"\\n" options:0 range:NSMakeRange(0, escaped.length)];
        [escaped replaceOccurrencesOfString:@"\r" withString:@"\\r" options:0 range:NSMakeRange(0, escaped.length)];
        [escaped replaceOccurrencesOfString:@"\t" withString:@"\\t" options:0 range:NSMakeRange(0, escaped.length)];
        return [NSString stringWithFormat:@"\"%@\"", escaped];
    }
    if ([value isKindOfClass:[NSNumber class]]) {
        if (CFGetTypeID((__bridge CFTypeRef)value) == CFBooleanGetTypeID()) {
            return [(NSNumber *)value boolValue] ? @"true" : @"false";
        }
        return [(NSNumber *)value stringValue];
    }
    if ([value isKindOfClass:[NSDate class]]) {
        static NSDateFormatter *formatter;
        static dispatch_once_t once;
        dispatch_once(&once, ^{
            formatter = [NSDateFormatter new];
            formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss.SSS";
        });
        return [formatter stringFromDate:(NSDate *)value];
    }
    if ([value isKindOfClass:[NSData class]]) {
        return [NSString stringWithFormat:@"<data %lu bytes>", (unsigned long)[(NSData *)value length]];
    }
    if ([value isKindOfClass:[NSArray class]]) {
        NSArray *array = (NSArray *)value;
        if (array.count == 0) return @"[ ]";
        NSMutableString *out = [NSMutableString stringWithString:@"[\n"];
        for (NSUInteger i = 0; i < array.count; i++) {
            [out appendFormat:@"%@%@%@\n", PPMIndent(depth + 1),
                PPMFormatValueAtDepth(array[i], depth + 1),
                i + 1 < array.count ? @"," : @""];
        }
        [out appendFormat:@"%@]", PPMIndent(depth)];
        return out;
    }
    if ([value isKindOfClass:[NSDictionary class]]) {
        NSDictionary *dictionary = (NSDictionary *)value;
        if (dictionary.count == 0) return @"{ }";
        NSArray *keys = [dictionary.allKeys sortedArrayUsingComparator:^NSComparisonResult(id a, id b) {
            return [[a description] compare:[b description] options:NSLiteralSearch];
        }];
        NSMutableString *out = [NSMutableString stringWithString:@"{\n"];
        for (NSUInteger i = 0; i < keys.count; i++) {
            id key = keys[i];
            [out appendFormat:@"%@\"%@\" = %@%@\n", PPMIndent(depth + 1), [key description],
                PPMFormatValueAtDepth(dictionary[key], depth + 1),
                i + 1 < keys.count ? @";" : @""];
        }
        [out appendFormat:@"%@}", PPMIndent(depth)];
        return out;
    }
    return [value description] ?: @"nil";
}

NSString *PPMFormatValue(_Nullable id value) {
    return PPMFormatValueAtDepth(value, 0);
}

NSString *PPMFormatKeyPath(NSString *keyPath) {
    if (keyPath.length == 0) return @"/";
    return keyPath;
}
