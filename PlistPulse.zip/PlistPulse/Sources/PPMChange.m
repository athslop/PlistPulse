#import "PPMChange.h"
#include <CoreFoundation/CoreFoundation.h>
#include <string.h>

@implementation PPMChange

- (instancetype)initWithKind:(PPMChangeKind)kind
                    keyPath:(NSString *)keyPath
                   oldValue:(nullable id)oldValue
                   newValue:(nullable id)newValue
                       date:(NSDate *)date {
    self = [super init];
    if (self) {
        _kind = kind;
        _keyPath = [keyPath copy];
        _oldValue = oldValue;
        _newValue = newValue;
        _date = date ?: [NSDate date];
    }
    return self;
}

@end

NSString *PPMFormatValue(_Nullable id value) {
    if (value == nil || value == (id)[NSNull null]) return @"nil";
    if ([value isKindOfClass:[NSString class]]) {
        NSString *s = (NSString *)value;
        if (s.length > 120) s = [[s substringToIndex:120] stringByAppendingString:@"..."];
        return [NSString stringWithFormat:@"\"%@\"", s];
    }
    if ([value isKindOfClass:[NSNumber class]]) {
        if (CFGetTypeID((__bridge CFTypeRef)value) == CFBooleanGetTypeID()) {
            return [(NSNumber *)value boolValue] ? @"true" : @"false";
        }
        return [(NSNumber *)value stringValue];
    }
    if ([value isKindOfClass:[NSDate class]]) {
        static NSDateFormatter *f = nil;
        static dispatch_once_t once;
        dispatch_once(&once, ^{
            f = [[NSDateFormatter alloc] init];
            f.dateFormat = @"HH:mm:ss.SSS";
        });
        return [f stringFromDate:(NSDate *)value];
    }
    if ([value isKindOfClass:[NSData class]]) {
        return [NSString stringWithFormat:@"<data %lu bytes>", (unsigned long)[(NSData *)value length]];
    }
    if ([value isKindOfClass:[NSArray class]]) {
        return [NSString stringWithFormat:@"<array %lu items>", (unsigned long)[(NSArray *)value count]];
    }
    if ([value isKindOfClass:[NSDictionary class]]) {
        return [NSString stringWithFormat:@"<dict %lu keys>", (unsigned long)[(NSDictionary *)value count]];
    }
    NSString *desc = [value description];
    if (desc.length > 160) desc = [[desc substringToIndex:160] stringByAppendingString:@"..."];
    return desc;
}

NSString *PPMFormatKeyPath(NSString *keyPath) {
    if (keyPath.length == 0) return @"/";
    return keyPath;
}
