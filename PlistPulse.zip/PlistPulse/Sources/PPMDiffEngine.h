#import <Foundation/Foundation.h>
#import "PPMChange.h"

NS_ASSUME_NONNULL_BEGIN

@interface PPMDiffEngine : NSObject

+ (NSArray<PPMChange *> *)changesFrom:(nullable id)oldRoot
                                  to:(nullable id)newRoot;

+ (nullable id)readPlistAtPath:(NSString *)path;

@end

NS_ASSUME_NONNULL_END
