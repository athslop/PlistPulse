#import "PPMDiffEngine.h"
#import "PPMChange.h"

static void PPMWalk(id _Nullable oldValue, id _Nullable newValue, NSString *keyPath,
                    NSDate *date, NSMutableArray<PPMChange *> *result) {
    if (oldValue == (id)[NSNull null]) oldValue = nil;
    if (newValue == (id)[NSNull null]) newValue = nil;
    if (oldValue == newValue) return;
    if (oldValue != nil && [oldValue isEqual:newValue]) return;

    BOOL oldDict = [oldValue isKindOfClass:[NSDictionary class]];
    BOOL newDict = [newValue isKindOfClass:[NSDictionary class]];
    if (oldDict && newDict) {
        NSDictionary *before = (NSDictionary *)oldValue;
        NSDictionary *after = (NSDictionary *)newValue;
        NSArray *keys = [[[NSSet setWithArray:before.allKeys]
                          setByAddingObjectsFromArray:after.allKeys].allObjects
                         sortedArrayUsingComparator:^NSComparisonResult(id a, id b) {
            return [[a description] compare:[b description] options:NSLiteralSearch];
        }];
        for (id key in keys) {
            if (![key isKindOfClass:[NSString class]]) {
                if (before[key] != nil) {
                    [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindRemoved
                        keyPath:[NSString stringWithFormat:@"%@/%@", keyPath, [key description]]
                        oldValue:before[key] newValue:nil date:date]];
                }
                if (after[key] != nil) {
                    [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindAdded
                        keyPath:[NSString stringWithFormat:@"%@/%@", keyPath, [key description]]
                        oldValue:nil newValue:after[key] date:date]];
                }
                continue;
            }
            id childOld = before[key];
            id childNew = after[key];
            NSString *childPath = [keyPath stringByAppendingFormat:@"/%@", key];
            if (childOld == nil && childNew != nil) {
                [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindAdded
                    keyPath:childPath oldValue:nil newValue:childNew date:date]];
            } else if (childOld != nil && childNew == nil) {
                [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindRemoved
                    keyPath:childPath oldValue:childOld newValue:nil date:date]];
            } else if (childOld != nil && childNew != nil) {
                PPMWalk(childOld, childNew, childPath, date, result);
            }
        }
        return;
    }

    if ([oldValue isKindOfClass:[NSArray class]] && [newValue isKindOfClass:[NSArray class]]) {
        NSArray *before = (NSArray *)oldValue;
        NSArray *after = (NSArray *)newValue;
        NSUInteger common = MIN(before.count, after.count);
        for (NSUInteger i = 0; i < common; i++) {
            PPMWalk(before[i], after[i], [keyPath stringByAppendingFormat:@"/%lu", (unsigned long)i], date, result);
        }
        for (NSUInteger i = common; i < before.count; i++) {
            [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindRemoved
                keyPath:[keyPath stringByAppendingFormat:@"/%lu", (unsigned long)i]
                oldValue:before[i] newValue:nil date:date]];
        }
        for (NSUInteger i = common; i < after.count; i++) {
            [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindAdded
                keyPath:[keyPath stringByAppendingFormat:@"/%lu", (unsigned long)i]
                oldValue:nil newValue:after[i] date:date]];
        }
        return;
    }

    if (oldValue != nil && newValue == nil) {
        [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindRemoved
            keyPath:keyPath oldValue:oldValue newValue:nil date:date]];
    } else if (oldValue == nil && newValue != nil) {
        [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindAdded
            keyPath:keyPath oldValue:nil newValue:newValue date:date]];
    } else if (oldValue != nil && newValue != nil) {
        [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindChanged
            keyPath:keyPath oldValue:oldValue newValue:newValue date:date]];
    }
}

@implementation PPMDiffEngine

+ (NSArray<PPMChange *> *)changesFrom:(nullable id)oldRoot to:(nullable id)newRoot {
    NSMutableArray<PPMChange *> *result = [NSMutableArray array];
    PPMWalk(oldRoot, newRoot, @"", [NSDate date], result);
    return result;
}

+ (nullable id)readPlistAtPath:(NSString *)path {
    NSData *data = [NSData dataWithContentsOfFile:path options:NSDataReadingUncached error:nil];
    if (data == nil) return nil;
    return [NSPropertyListSerialization propertyListWithData:data
        options:NSPropertyListImmutable format:nil error:nil];
}

@end
