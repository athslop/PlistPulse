#import "PPMDiffEngine.h"
#import "PPMChange.h"

static void PPMWalk(id _Nullable oldValue, id _Nullable updatedValue, NSString *keyPath,
                    NSDate *date, NSMutableArray<PPMChange *> *result) {
    if (oldValue == (id)[NSNull null]) oldValue = nil;
    if (updatedValue == (id)[NSNull null]) updatedValue = nil;
    if (oldValue == updatedValue) return;
    if (oldValue != nil && [oldValue isEqual:updatedValue]) return;

    BOOL oldDict = [oldValue isKindOfClass:[NSDictionary class]];
    BOOL newDict = [updatedValue isKindOfClass:[NSDictionary class]];
    if (oldDict && newDict) {
        NSDictionary *before = (NSDictionary *)oldValue;
        NSDictionary *after = (NSDictionary *)updatedValue;
        NSArray *keys = [[[NSSet setWithArray:before.allKeys]
                          setByAddingObjectsFromArray:after.allKeys].allObjects
                         sortedArrayUsingComparator:^NSComparisonResult(id a, id b) {
            return [[a description] compare:[b description] options:NSLiteralSearch];
        }];
        for (id key in keys) {
            if (![key isKindOfClass:[NSString class]]) {
                if (before[key] != nil) {
                    [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindRemoved
                        keyPath:[NSString stringWithFormat:@"%@/%@", keyPath, [key description]]
                        oldValue:before[key] updatedValue:nil date:date]];
                }
                if (after[key] != nil) {
                    [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindAdded
                        keyPath:[NSString stringWithFormat:@"%@/%@", keyPath, [key description]]
                        oldValue:nil updatedValue:after[key] date:date]];
                }
                continue;
            }
            id childOld = before[key];
            id childNew = after[key];
            NSString *childPath = [keyPath stringByAppendingFormat:@"/%@", key];
            if (childOld == nil && childNew != nil) {
                [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindAdded
                    keyPath:childPath oldValue:nil updatedValue:childNew date:date]];
            } else if (childOld != nil && childNew == nil) {
                [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindRemoved
                    keyPath:childPath oldValue:childOld updatedValue:nil date:date]];
            } else if (childOld != nil && childNew != nil) {
                PPMWalk(childOld, childNew, childPath, date, result);
            }
        }
        return;
    }

    if ([oldValue isKindOfClass:[NSArray class]] && [updatedValue isKindOfClass:[NSArray class]]) {
        NSArray *before = (NSArray *)oldValue;
        NSArray *after = (NSArray *)updatedValue;
        NSUInteger common = MIN(before.count, after.count);
        for (NSUInteger i = 0; i < common; i++) {
            PPMWalk(before[i], after[i], [keyPath stringByAppendingFormat:@"/%lu", (unsigned long)i], date, result);
        }
        for (NSUInteger i = common; i < before.count; i++) {
            [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindRemoved
                keyPath:[keyPath stringByAppendingFormat:@"/%lu", (unsigned long)i]
                oldValue:before[i] updatedValue:nil date:date]];
        }
        for (NSUInteger i = common; i < after.count; i++) {
            [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindAdded
                keyPath:[keyPath stringByAppendingFormat:@"/%lu", (unsigned long)i]
                oldValue:nil updatedValue:after[i] date:date]];
        }
        return;
    }

    if (oldValue != nil && updatedValue == nil) {
        [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindRemoved
            keyPath:keyPath oldValue:oldValue updatedValue:nil date:date]];
    } else if (oldValue == nil && updatedValue != nil) {
        [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindAdded
            keyPath:keyPath oldValue:nil updatedValue:updatedValue date:date]];
    } else if (oldValue != nil && updatedValue != nil) {
        [result addObject:[[PPMChange alloc] initWithKind:PPMChangeKindChanged
            keyPath:keyPath oldValue:oldValue updatedValue:updatedValue date:date]];
    }
}

@implementation PPMDiffEngine

+ (NSArray<PPMChange *> *)changesFrom:(nullable id)oldRoot to:(nullable id)newRoot {
    NSMutableArray<PPMChange *> *result = [NSMutableArray array];
    PPMWalk(oldRoot, newRoot, @"", [NSDate date], result);
    return result;
}

+ (nullable id)readPlistAtPath:(NSString *)path {
    NSData *data = [NSData dataWithContentsOfFile:path options:NSDataReadingUncached error:nil];
    if (data == nil) return nil;
    return [NSPropertyListSerialization propertyListWithData:data
        options:NSPropertyListImmutable format:nil error:nil];
}

@end
