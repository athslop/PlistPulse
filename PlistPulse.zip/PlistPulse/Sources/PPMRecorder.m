#import <Foundation/Foundation.h>
#import "PPMShared.h"
#import "PPMChange.h"
#import "PPMDiffEngine.h"
#include <fcntl.h>
#include <unistd.h>

static id PPMSafeJSONValue(id _Nullable value) {
    if (value == nil) return [NSNull null];
    if ([NSJSONSerialization isValidJSONObject:value]) return value;
    if ([value isKindOfClass:[NSDate class]]) return [NSString stringWithFormat:@"<date %@>", value];
    if ([value isKindOfClass:[NSData class]]) return PPMFormatValue(value);
    if ([value isKindOfClass:[NSArray class]]) {
        NSMutableArray *array = [NSMutableArray array];
        for (id child in value) [array addObject:PPMSafeJSONValue(child)];
        return array;
    }
    if ([value isKindOfClass:[NSDictionary class]]) {
        NSMutableDictionary *dictionary = [NSMutableDictionary dictionary];
        for (id key in value) dictionary[[key description]] = PPMSafeJSONValue(value[key]);
        return dictionary;
    }
    return PPMFormatValue(value);
}

static void PPMAppendLog(NSArray<PPMChange *> *changes) {
    if (changes.count == 0) return;
    @autoreleasepool {
    NSString *logPath = PPMLogPath();
    if (![[NSFileManager defaultManager] fileExistsAtPath:logPath]) {
        [[NSFileManager defaultManager] createFileAtPath:logPath contents:nil
            attributes:@{NSFilePosixPermissions: @0600}];
    }
    NSFileHandle *handle = [NSFileHandle fileHandleForWritingAtPath:logPath];
    if (!handle) return;
    [handle seekToEndOfFile];
    for (PPMChange *change in changes) {
        NSString *kind = change.kind == PPMChangeKindAdded ? @"ADDED" :
            change.kind == PPMChangeKindRemoved ? @"REMOVED" : @"CHANGED";
        NSDictionary *event = @{@"timestamp": @(change.date.timeIntervalSince1970), @"kind": kind,
            @"path": PPMFormatKeyPath(change.keyPath), @"old": PPMSafeJSONValue(change.oldValue),
            @"new": PPMSafeJSONValue(change.newValue)};
        NSData *data = [NSJSONSerialization dataWithJSONObject:event options:0 error:nil];
        if (data) {
            NSMutableData *line = [data mutableCopy];
            [line appendBytes:"\n" length:1];
            [handle writeData:line];
        }
    }
    [handle closeFile];
    }
}

@interface PPMRecorderSession : NSObject
@property (nonatomic, strong) dispatch_queue_t queue;
@property (nonatomic, strong, nullable) dispatch_source_t vnodeSource;
@property (nonatomic, strong, nullable) dispatch_source_t timerSource;
@property (nonatomic, copy, nullable) NSString *currentPath;
@property (nonatomic, strong, nullable) id snapshot;
- (void)check;
- (void)attachVnode;
- (void)reload;
@end

@implementation PPMRecorderSession

- (instancetype)init {
    self = [super init];
    if (self) _queue = dispatch_queue_create("dev.plistpulse.recorder", DISPATCH_QUEUE_SERIAL);
    return self;
}

- (void)check {
    if (self.currentPath == nil) return;
    id updated = [PPMDiffEngine readPlistAtPath:self.currentPath];
    if (updated == nil) return; // Ignore a transient missing or partially-written file.
    if ([self.snapshot isEqual:updated]) return;
    NSArray<PPMChange *> *changes = [PPMDiffEngine changesFrom:self.snapshot to:updated];
    self.snapshot = updated;
    PPMAppendLog(changes);
}

- (void)attachVnode {
    if (self.vnodeSource) dispatch_source_cancel(self.vnodeSource);
    self.vnodeSource = nil;
    if (self.currentPath == nil) return;
    int descriptor = open(self.currentPath.fileSystemRepresentation, O_EVTONLY);
    if (descriptor < 0) return;
    self.vnodeSource = dispatch_source_create(DISPATCH_SOURCE_TYPE_VNODE, (uintptr_t)descriptor,
        DISPATCH_VNODE_WRITE | DISPATCH_VNODE_RENAME | DISPATCH_VNODE_DELETE |
        DISPATCH_VNODE_EXTEND | DISPATCH_VNODE_ATTRIB | DISPATCH_VNODE_REVOKE, self.queue);
    __weak typeof(self) weakSelf = self;
    dispatch_source_set_event_handler(self.vnodeSource, ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        [strongSelf check];
        [strongSelf attachVnode]; // Atomic replacements invalidate the old descriptor.
    });
    dispatch_source_set_cancel_handler(self.vnodeSource, ^{ close(descriptor); });
    dispatch_resume(self.vnodeSource);
}

- (void)reload {
    NSData *data = [NSData dataWithContentsOfFile:PPMControlPath()];
    NSDictionary *configuration = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
    NSString *path = [configuration isKindOfClass:[NSDictionary class]] ? configuration[@"path"] : nil;
    if (![path isKindOfClass:[NSString class]] || path.length == 0) {
        exit(0); // The UI explicitly bootstraps the on-demand job for a new session.
    }
    if ([self.currentPath isEqual:path]) return;
    self.currentPath = path;
    self.snapshot = [PPMDiffEngine readPlistAtPath:self.currentPath];
    if (self.snapshot == nil) {
        self.currentPath = nil;
        NSLog(@"PlistPulse: cannot read the selected plist; recording is inactive");
        return;
    }
    [self attachVnode];
}

@end

int main(int argc, char **argv) {
    @autoreleasepool {
        NSString *directory = PPMSharedDirectory();
        [[NSFileManager defaultManager] createDirectoryAtPath:directory
            withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions: @0700} error:nil];
        chmod(directory.fileSystemRepresentation, 0700);

        PPMRecorderSession *session = [PPMRecorderSession new];
        session.timerSource = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, session.queue);
        dispatch_source_set_timer(session.timerSource, dispatch_time(DISPATCH_TIME_NOW, 0),
            (uint64_t)(0.15 * NSEC_PER_SEC), (uint64_t)(0.05 * NSEC_PER_SEC));
        dispatch_source_set_event_handler(session.timerSource, ^{
            [session reload];
            [session check];
        });
        dispatch_resume(session.timerSource);
        dispatch_async(session.queue, ^{ [session reload]; });
        dispatch_main();
    }
    return 0;
}
