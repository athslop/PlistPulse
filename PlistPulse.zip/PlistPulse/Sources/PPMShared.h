#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString * const PPMControlFileName;
extern NSString * const PPMLogFileName;
extern NSString * const PPMRequestNotification;

NSString *PPMSharedDirectory(void);
NSString *PPMControlPath(void);
NSString *PPMLogPath(void);
NSString *PPMRecorderPIDPath(void);

BOOL PPMConfigureBackgroundRecording(NSString *_Nullable path, NSError **error);
BOOL PPMBackgroundRecorderAvailable(void);
NSString *PPMBackgroundStatus(void);
NSArray<NSDictionary *> *PPMReadNewEvents(unsigned long long *offset);

NS_ASSUME_NONNULL_END
