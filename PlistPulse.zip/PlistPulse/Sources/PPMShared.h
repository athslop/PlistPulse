#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString * const PPMControlFileName;
extern NSString * const PPMLogFileName;

NSString *PPMSharedDirectory(void);
NSString *PPMControlPath(void);
NSString *PPMLogPath(void);
BOOL PPMConfigureBackgroundRecording(NSString *_Nullable path, NSError **error);
BOOL PPMBackgroundRecorderAvailable(void);
NSString *PPMBackgroundStatus(void);
BOOL PPMRunBackgroundCommand(NSString *command, NSError **error);
NSArray<NSDictionary *> *PPMReadNewEvents(unsigned long long *offset);

NS_ASSUME_NONNULL_END
