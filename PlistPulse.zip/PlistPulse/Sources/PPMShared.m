#import "PPMShared.h"
#include <roothide.h>
#include <errno.h>
#include <signal.h>
#include <sys/stat.h>
#include <unistd.h>

NSString * const PPMControlFileName = @"control.json";
NSString * const PPMLogFileName = @"events.jsonl";
NSString * const PPMRequestNotification = @"dev.plistpulse.reload";

NSString *PPMSharedDirectory(void) {
    return jbroot(@"/var/mobile/Library/PlistPulse");
}

NSString *PPMControlPath(void) {
    return [PPMSharedDirectory() stringByAppendingPathComponent:PPMControlFileName];
}

NSString *PPMLogPath(void) {
    return [PPMSharedDirectory() stringByAppendingPathComponent:PPMLogFileName];
}

NSString *PPMRecorderPIDPath(void) {
    return [PPMSharedDirectory() stringByAppendingPathComponent:@"recorder.pid"];
}

BOOL PPMConfigureBackgroundRecording(NSString *_Nullable path, NSError **error) {
    NSString *directory = PPMSharedDirectory();
    [[NSFileManager defaultManager] createDirectoryAtPath:directory
        withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions: @0755} error:nil];
    if (path == nil) {
        [[NSFileManager defaultManager] removeItemAtPath:PPMControlPath() error:nil];
    } else {
        NSData *json = [NSJSONSerialization dataWithJSONObject:@{@"path": path} options:0 error:error];
        if (json == nil || ![json writeToFile:PPMControlPath() atomically:YES]) {
            if (error && *error == nil) {
                *error = [NSError errorWithDomain:@"dev.plistpulse" code:2
                    userInfo:@{NSLocalizedDescriptionKey: @"Could not save the recording configuration."}];
            }
            return NO;
        }
    }
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
        (__bridge CFStringRef)PPMRequestNotification, NULL, NULL, true);
    return YES;
}

BOOL PPMBackgroundRecorderAvailable(void) {
    NSString *pidText = [NSString stringWithContentsOfFile:PPMRecorderPIDPath()
        encoding:NSUTF8StringEncoding error:nil];
    pid_t pid = (pid_t)pidText.intValue;
    if (pid <= 0) return NO;
    // EPERM still proves the root-owned recorder is alive.
    return kill(pid, 0) == 0 || errno == EPERM;
}

NSString *PPMBackgroundStatus(void) {
    return PPMBackgroundRecorderAvailable() ? @"Background recorder running"
                                            : @"Background recorder not running";
}

NSArray<NSDictionary *> *PPMReadNewEvents(unsigned long long *offset) {
    NSFileHandle *handle = [NSFileHandle fileHandleForReadingAtPath:PPMLogPath()];
    if (handle == nil) return @[];
    @try {
        unsigned long long length = [handle seekToEndOfFile];
        unsigned long long start = MIN(*offset, length);
        [handle seekToFileOffset:start];
        NSData *data = [handle readDataToEndOfFile];
        *offset = length;
        NSString *text = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        if (text.length == 0) return @[];
        NSMutableArray *events = [NSMutableArray array];
        for (NSString *line in [text componentsSeparatedByString:@"\n"]) {
            if (line.length == 0) continue;
            id object = [NSJSONSerialization JSONObjectWithData:[line dataUsingEncoding:NSUTF8StringEncoding]
                options:0 error:nil];
            if ([object isKindOfClass:[NSDictionary class]]) [events addObject:object];
        }
        if (events.count > 1000) [events removeObjectsInRange:NSMakeRange(0, events.count - 1000)];
        return events;
    } @catch (__unused NSException *exception) {
        return @[];
    } @finally {
        [handle closeFile];
    }
}
