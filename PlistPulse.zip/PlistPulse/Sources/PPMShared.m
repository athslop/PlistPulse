#import "PPMShared.h"
#import "PPMChange.h"
#include <roothide.h>
#include <spawn.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <unistd.h>

NSString * const PPMControlFileName = @"control.json";
NSString * const PPMLogFileName = @"events.jsonl";

NSString *PPMSharedDirectory(void) {
    return jbroot(@"/var/mobile/Library/PlistPulse");

}
NSString *PPMControlPath(void) {
    return [PPMSharedDirectory() stringByAppendingPathComponent:PPMControlFileName];
}
NSString *PPMLogPath(void) {
    return [PPMSharedDirectory() stringByAppendingPathComponent:PPMLogFileName];
}

static BOOL PPMRunCommand(NSString *program, NSArray<NSString *> *arguments, NSError **error) {
    NSUInteger count = arguments.count;
    char **argv = calloc(count + 1, sizeof(char *));
    if (!argv) return NO;
    for (NSUInteger i = 0; i < count; i++) argv[i] = (char *)arguments[i].UTF8String;
    pid_t pid = 0;
    int result = posix_spawn(&pid, jbroot(program.UTF8String), NULL, NULL, argv, NULL);
    free(argv);
    if (result != 0) {
        if (error) *error = [NSError errorWithDomain:@"dev.plistpulse" code:result
            userInfo:@{NSLocalizedDescriptionKey: @"Could not start the RootHide background recorder."}];
        return NO;
    }
    int status = 0;
    if (waitpid(pid, &status, 0) < 0 || !WIFEXITED(status) || WEXITSTATUS(status) != 0) {
        if (error) *error = [NSError errorWithDomain:@"dev.plistpulse" code:1
            userInfo:@{NSLocalizedDescriptionKey: @"The RootHide background recorder command failed."}];
        return NO;
    }
    return YES;
}

BOOL PPMConfigureBackgroundRecording(NSString *_Nullable path, NSError **error) {
    NSString *directory = PPMSharedDirectory();
    [[NSFileManager defaultManager] createDirectoryAtPath:directory
        withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions: @0700} error:nil];
    if (path != nil) {
        NSData *json = [NSJSONSerialization dataWithJSONObject:@{@"path": path} options:0 error:error];
        if (json == nil || ![json writeToFile:PPMControlPath() atomically:YES]) {
            if (error && *error == nil) *error = [NSError errorWithDomain:@"dev.plistpulse" code:2
                userInfo:@{NSLocalizedDescriptionKey: @"Could not save the recording configuration."}];
            return NO;
        }
    } else {
        [[NSFileManager defaultManager] removeItemAtPath:PPMControlPath() error:nil];
    }
    return YES;
}

BOOL PPMBackgroundRecorderAvailable(void) {
    return access(jbroot("/Library/LaunchDaemons/dev.plistpulse.recorder.plist").fileSystemRepresentation, F_OK) == 0;
}

BOOL PPMRunBackgroundCommand(NSString *command, NSError **error) {
    if (![@[@"bootstrap", @"bootout"] containsObject:command]) return NO;
    NSString *plist = @"/Library/LaunchDaemons/dev.plistpulse.recorder.plist";
    return PPMRunCommand(@"/usr/bin/launchctl", @[@"launchctl", command, @"system", plist], error);
}

NSString *PPMBackgroundStatus(void) {
    NSString *program = jbroot(@"/usr/bin/launchctl");
    if (access(program.fileSystemRepresentation, X_OK) != 0) return @"RootHide recorder unavailable";
    NSPipe *pipe = [NSPipe pipe];
    posix_spawn_file_actions_t actions;
    posix_spawn_file_actions_init(&actions);
    posix_spawn_file_actions_adddup2(&actions, pipe.fileHandleForWriting.fileDescriptor, STDOUT_FILENO);
    posix_spawn_file_actions_adddup2(&actions, pipe.fileHandleForWriting.fileDescriptor, STDERR_FILENO);
    posix_spawn_file_actions_addclose(&actions, pipe.fileHandleForReading.fileDescriptor);
    char *argv[] = {"launchctl", "print", "system/dev.plistpulse.recorder", NULL};
    pid_t pid = 0;
    int result = posix_spawn(&pid, program.fileSystemRepresentation, &actions, NULL, argv, NULL);
    posix_spawn_file_actions_destroy(&actions);
    [pipe.fileHandleForWriting closeFile];
    if (result != 0) return @"RootHide recorder unavailable";
    NSData *data = [pipe.fileHandleForReading readDataToEndOfFile];
    int status = 0;
    waitpid(pid, &status, 0);
    NSString *output = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    if ([output rangeOfString:@"state = running"].location != NSNotFound) return @"Background recorder running";
    if ([output rangeOfString:@"last exit code ="].location != NSNotFound) return @"Recorder needs a restart";
    return @"Recorder starting…";
}

NSArray<NSDictionary *> *PPMReadNewEvents(unsigned long long *offset) {
    NSFileHandle *handle = [NSFileHandle fileHandleForReadingAtPath:PPMLogPath()];
    if (handle == nil) return @[];
    @try {
        unsigned long long length = [handle seekToEndOfFile];
        unsigned long long start = MIN(*offset, length);
        [handle seekToFileOffset:start];
        NSData *data = [handle readDataToEndOfFile];
        *offset = length;
        NSString *text = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        if (text.length == 0) return @[];
        NSArray *lines = [text componentsSeparatedByString:@"\n"];
        NSMutableArray *events = [NSMutableArray array];
        for (NSString *line in lines) {
            if (line.length == 0) continue;
            id object = [NSJSONSerialization JSONObjectWithData:[line dataUsingEncoding:NSUTF8StringEncoding]
                options:0 error:nil];
            if ([object isKindOfClass:[NSDictionary class]]) [events addObject:object];
        }
        if (events.count > 1000) [events removeObjectsInRange:NSMakeRange(0, events.count - 1000)];
        return events;
    } @catch (__unused NSException *exception) {
        return @[];
    } @finally {
        [handle closeFile];
    }
}
