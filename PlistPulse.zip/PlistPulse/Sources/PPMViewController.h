#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PPMViewController : UIViewController

- (void)openPath:(NSString *)path;

@end

NS_ASSUME_NONNULL_END
