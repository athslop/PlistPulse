#import "PPMViewController.h"
#import "PPMChange.h"
#import "PPMDiffEngine.h"
#import "PPMShared.h"

static NSDateFormatter *PPMTimeFormatter(void) {
    static NSDateFormatter *formatter;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        formatter = [NSDateFormatter new];
        formatter.dateFormat = @"HH:mm:ss.SSS";
    });
    return formatter;
}

static NSDate *PPMEventDate(NSDictionary *event) {
    if ([event[@"timestamp"] isKindOfClass:[NSNumber class]]) {
        return [NSDate dateWithTimeIntervalSince1970:[event[@"timestamp"] doubleValue]];
    }
    return [NSDate date];
}

static NSString *PPMEventText(NSDictionary *event) {
    NSString *kind = [event[@"kind"] isKindOfClass:[NSString class]] ? event[@"kind"] : @"CHANGED";
    NSString *key = [event[@"path"] isKindOfClass:[NSString class]] ? event[@"path"] : @"/";
    id oldValue = event[@"old"] == [NSNull null] ? nil : event[@"old"];
    id updatedValue = event[@"new"] == [NSNull null] ? nil : event[@"new"];
    NSString *before = oldValue ? PPMFormatValue(oldValue) : @"";
    NSString *after = updatedValue ? PPMFormatValue(updatedValue) : @"";
    if ([kind isEqualToString:@"ADDED"]) return [NSString stringWithFormat:@"ADDED %@ = %@", key, after];
    if ([kind isEqualToString:@"REMOVED"]) return [NSString stringWithFormat:@"REMOVED %@ (was %@)", key, before];
    return [NSString stringWithFormat:@"CHANGED %@: %@ -> %@", key, before, after];
}

@interface PPMViewController () <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITextField *pathField;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UIButton *recordButton;
@property (nonatomic, strong) UIButton *pauseButton;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *events;
@property (nonatomic, copy, nullable) NSString *currentPath;
@property (nonatomic, assign) BOOL recording;
@property (nonatomic, assign) BOOL paused;
@property (nonatomic, assign) BOOL importedCopy;
@property (nonatomic, strong) NSTimer *refreshTimer;
@property (nonatomic, assign) unsigned long long logOffset;
@end

@implementation PPMViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"PlistPulse";
    self.view.backgroundColor = [UIColor systemBackgroundColor];
    self.events = [NSMutableArray array];
    [self buildInterface];
    self.refreshTimer = [NSTimer scheduledTimerWithTimeInterval:0.25 target:self
        selector:@selector(refreshBackgroundLog) userInfo:nil repeats:YES];
    [self refreshBackgroundStatus];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self refreshBackgroundStatus];
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleDefault;
}

- (void)buildInterface {
    UIStackView *content = [UIStackView new];
    content.axis = UILayoutConstraintAxisVertical;
    content.spacing = 10;
    content.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:content];

    UILabel *heading = [UILabel new];
    heading.text = @"LIVE PLIST MONITOR";
    heading.font = [UIFont boldSystemFontOfSize:13];
    heading.textColor = [UIColor secondaryLabelColor];
    [content addArrangedSubview:heading];

    self.pathField = [UITextField new];
    self.pathField.placeholder = @"/path/to/file.plist";
    self.pathField.borderStyle = UITextBorderStyleRoundedRect;
    self.pathField.font = [UIFont monospacedSystemFontOfSize:14 weight:UIFontWeightRegular];
    self.pathField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.pathField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.pathField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.pathField.spellCheckingType = UITextSpellCheckingTypeNo;
    self.pathField.returnKeyType = UIReturnKeyDone;
    [self.pathField addTarget:self action:@selector(endEditing) forControlEvents:UIControlEventEditingDidEndOnExit];
    [content addArrangedSubview:self.pathField];

    UIButton *paste = [self buttonWithTitle:@"Paste path from Filza" color:[UIColor systemGrayColor]
        action:@selector(pasteFilzaPath)];
    [content addArrangedSubview:paste];

    self.recordButton = [self buttonWithTitle:@"Start monitoring" color:[UIColor systemGreenColor]
        action:@selector(toggleRecording)];
    [content addArrangedSubview:self.recordButton];

    UIStackView *tools = [UIStackView new];
    tools.axis = UILayoutConstraintAxisHorizontal;
    tools.spacing = 8;
    tools.distribution = UIStackViewDistributionFillEqually;
    self.pauseButton = [self buttonWithTitle:@"Pause log" color:[UIColor systemOrangeColor] action:@selector(togglePause)];
    [tools addArrangedSubview:self.pauseButton];
    [tools addArrangedSubview:[self buttonWithTitle:@"Clear" color:[UIColor systemGrayColor] action:@selector(clearLog)]];
    [tools addArrangedSubview:[self buttonWithTitle:@"Share" color:[UIColor systemIndigoColor] action:@selector(shareLog)]];
    [content addArrangedSubview:tools];

    self.statusLabel = [UILabel new];
    self.statusLabel.numberOfLines = 3;
    self.statusLabel.font = [UIFont systemFontOfSize:12];
    self.statusLabel.textColor = [UIColor secondaryLabelColor];
    self.statusLabel.text = @"Paste a full plist path from Filza to begin.";
    [content addArrangedSubview:self.statusLabel];

    self.tableView = [UITableView new];
    self.tableView.translatesAutoresizingMaskIntoConstraints = NO;
    self.tableView.estimatedRowHeight = 74;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeInteractive;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:self.tableView];

    UILayoutGuide *safe = self.view.safeAreaLayoutGuide;
    [NSLayoutConstraint activateConstraints:@[
        [content.topAnchor constraintEqualToAnchor:safe.topAnchor constant:12],
        [content.leadingAnchor constraintEqualToAnchor:safe.leadingAnchor constant:16],
        [content.trailingAnchor constraintEqualToAnchor:safe.trailingAnchor constant:-16],
        [self.tableView.topAnchor constraintEqualToAnchor:content.bottomAnchor constant:12],
        [self.tableView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.tableView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.tableView.bottomAnchor constraintEqualToAnchor:safe.bottomAnchor],
    ]];
}

- (UIButton *)buttonWithTitle:(NSString *)title color:(UIColor *)color action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    [button setTitle:title forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    button.titleLabel.adjustsFontSizeToFitWidth = YES;
    button.titleLabel.minimumScaleFactor = 0.8;
    [button setTitleColor:color forState:UIControlStateNormal];
    button.layer.borderWidth = 1;
    button.layer.borderColor = color.CGColor;
    button.layer.cornerRadius = 8;
    [button.heightAnchor constraintEqualToConstant:40].active = YES;
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}

- (void)endEditing {
    [self.pathField resignFirstResponder];
}

- (void)pasteFilzaPath {
    NSString *clipboard = UIPasteboard.generalPasteboard.string;
    if (clipboard.length == 0) {
        [self showMessage:@"Copy the plist's full path in Filza first, then tap Paste path from Filza." title:@"No path on clipboard"];
        return;
    }
    self.pathField.text = clipboard;
    [self openPath:clipboard];
}

- (void)openPath:(NSString *)path {
    NSString *clean = [path stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (![clean hasPrefix:@"/"]) {
        [self showMessage:@"Paste the absolute path, for example /var/mobile/Library/Preferences/example.plist" title:@"Invalid path"];
        return;
    }
    [self stopMonitoring];
    self.pathField.text = clean;
    self.importedCopy = [clean containsString:@"/Documents/Inbox/"];
    [self startMonitoring:clean];
}

- (void)toggleRecording {
    if (self.recording) {
        [self stopMonitoring];
        [self updateStatus];
        return;
    }
    NSString *path = [self.pathField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    self.importedCopy = [path containsString:@"/Documents/Inbox/"];
    [self startMonitoring:path];
}

- (void)startMonitoring:(NSString *)path {
    if (![path hasPrefix:@"/"]) {
        [self showMessage:@"Enter an absolute plist path." title:@"Invalid path"];
        return;
    }
    BOOL isDirectory = NO;
    if (![[NSFileManager defaultManager] fileExistsAtPath:path isDirectory:&isDirectory] || isDirectory) {
        [self showMessage:@"The file does not exist or is not accessible to PlistPulse." title:@"Cannot access plist"];
        return;
    }
    if ([PPMDiffEngine readPlistAtPath:path] == nil) {
        [self showMessage:@"The file is empty or is not a valid plist. Monitoring starts only when its current contents can be read." title:@"Invalid plist"];
        return;
    }

    self.logOffset = 0;
    if (self.importedCopy) {
        self.currentPath = path;
        self.recording = NO;
        self.statusLabel.text = [NSString stringWithFormat:@"IMPORTED COPY — NOT LIVE\n%@\nFilza imported a copy. Copy the original plist's full path in Filza, then paste it here.", path];
        [self showMessage:@"For live changes, use Filza > plist > More > Copy path, then paste the original path. The imported copy can only be read as a static snapshot." title:@"Imported copy"];
        return;
    }
    if (!PPMBackgroundRecorderAvailable()) {
        [self showMessage:@"The background recorder is not running. Reboot userspace (or run 'launchctl bootstrap system /Library/LaunchDaemons/dev.plistpulse.recorder.plist' as root), then try again." title:@"Recorder unavailable"];
        return;
    }

    NSError *error = nil;
    if (!PPMConfigureBackgroundRecording(path, &error)) {
        [self showMessage:error.localizedDescription title:@"Cannot configure recorder"];
        return;
    }
    [[NSFileManager defaultManager] removeItemAtPath:PPMLogPath() error:nil];
    self.currentPath = path;
    self.recording = YES;
    self.paused = NO;
    [self.events removeAllObjects];
    [self.tableView reloadData];
    [self updateStatus];
}

- (void)stopMonitoring {
    BOOL wasRecording = self.recording;
    self.recording = NO;
    self.paused = NO;
    if (wasRecording && !self.importedCopy) {
        PPMConfigureBackgroundRecording(nil, nil);
        for (NSDictionary *event in PPMReadNewEvents(&_logOffset)) [self appendEvent:event];
    }
    [self updateStatus];
}

- (void)updateStatus {
    [self.recordButton setTitle:self.recording ? @"Stop monitoring" : @"Start monitoring" forState:UIControlStateNormal];
    UIColor *color = self.recording ? [UIColor systemRedColor] : [UIColor systemGreenColor];
    [self.recordButton setTitleColor:color forState:UIControlStateNormal];
    self.recordButton.layer.borderColor = color.CGColor;
    self.pauseButton.enabled = self.recording;
    if (!self.recording) {
        self.statusLabel.text = @"Stopped. Paste a full plist path from Filza to begin.";
        return;
    }
    NSString *mode = self.paused ? @"LOG PAUSED" : @"LIVE";
    NSString *background = self.paused ? @"Paused — return later to review saved changes" : PPMBackgroundStatus();
    self.statusLabel.text = [NSString stringWithFormat:@"%@  •  %@\n%@\nUse another app, then return to review saved changes.", mode, self.currentPath, background];
}

- (void)togglePause {
    if (!self.recording) return;
    self.paused = !self.paused;
    [self.pauseButton setTitle:self.paused ? @"Resume log" : @"Pause log" forState:UIControlStateNormal];
    [self updateStatus];
}

- (void)clearLog {
    [self.events removeAllObjects];
    [self.tableView reloadData];
    [[NSFileManager defaultManager] removeItemAtPath:PPMLogPath() error:nil];
    self.logOffset = 0;
}

- (void)shareLog {
    if (self.events.count == 0) {
        [self showMessage:@"There are no changes to export yet." title:@"Log is empty"];
        return;
    }
    NSMutableArray *lines = [NSMutableArray arrayWithObject:[NSString stringWithFormat:@"PlistPulse — %@", self.currentPath ?: @""]];
    for (NSDictionary *event in self.events) {
        [lines addObject:[NSString stringWithFormat:@"%@  %@", [PPMTimeFormatter() stringFromDate:PPMEventDate(event)], PPMEventText(event)]];
    }
    NSString *path = [NSTemporaryDirectory() stringByAppendingPathComponent:@"PlistPulse-log.txt"];
    [[lines componentsJoinedByString:@"\n"] writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    UIActivityViewController *activity = [[UIActivityViewController alloc] initWithActivityItems:@[[NSURL fileURLWithPath:path]] applicationActivities:nil];
    activity.popoverPresentationController.sourceView = self.view;
    [self presentViewController:activity animated:YES completion:nil];
}

- (void)refreshBackgroundLog {
    if (!self.recording || self.paused) return;
    for (NSDictionary *event in PPMReadNewEvents(&_logOffset)) [self appendEvent:event];
}

- (void)appendEvent:(NSDictionary *)event {
    if (self.paused) return;
    if (self.events.count >= 1000) [self.events removeObjectAtIndex:0];
    [self.events addObject:event];
    [self.tableView reloadData];
    if (self.events.count > 0) {
        [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.events.count - 1 inSection:0]
            atScrollPosition:UITableViewScrollPositionBottom animated:NO];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.events.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"event";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
        cell.textLabel.numberOfLines = 0;
        cell.detailTextLabel.numberOfLines = 0;
        cell.textLabel.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightRegular];
        cell.detailTextLabel.font = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular];
        cell.detailTextLabel.textColor = [UIColor secondaryLabelColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    NSDictionary *event = self.events[indexPath.row];
    cell.textLabel.text = PPMEventText(event);
    cell.detailTextLabel.text = [PPMTimeFormatter() stringFromDate:PPMEventDate(event)];
    NSString *kind = event[@"kind"];
    cell.textLabel.textColor = [kind isEqualToString:@"ADDED"] ? [UIColor systemGreenColor] :
        [kind isEqualToString:@"REMOVED"] ? [UIColor systemRedColor] : [UIColor labelColor];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *event = self.events[indexPath.row];
    NSString *text = [NSString stringWithFormat:@"%@\n%@", [PPMTimeFormatter() stringFromDate:PPMEventDate(event)], PPMEventText(event)];
    UIPasteboard.generalPasteboard.string = text;
    [self showMessage:@"The event was copied to the clipboard." title:@"Copied"];
}

- (void)refreshBackgroundStatus {
    if (self.recording) [self updateStatus];
}

- (void)showMessage:(NSString *)message title:(NSString *)title {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message
        preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
