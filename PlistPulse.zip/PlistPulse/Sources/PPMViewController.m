#import "PPMViewController.h"
#import "PPMChange.h"
#import "PPMDiffEngine.h"
#import "PPMShared.h"

static NSDateFormatter *PPMTimeFormatter(void) {
    static NSDateFormatter *formatter;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        formatter = [NSDateFormatter new];
        formatter.dateFormat = @"HH:mm:ss.SSS";
    });
    return formatter;
}

static NSDate *PPMEventDate(NSDictionary *event) {
    if ([event[@"timestamp"] isKindOfClass:[NSNumber class]]) {
        return [NSDate dateWithTimeIntervalSince1970:[event[@"timestamp"] doubleValue]];
    }
    return [NSDate date];
}

static NSDictionary *PPMEvent(PPMChange *change) {
    NSString *kind = change.kind == PPMChangeKindAdded ? @"ADDED" :
        change.kind == PPMChangeKindRemoved ? @"REMOVED" : @"CHANGED";
    return @{@"timestamp": @(change.date.timeIntervalSince1970), @"kind": kind,
        @"path": PPMFormatKeyPath(change.keyPath), @"old": change.oldValue ?: [NSNull null],
        @"new": change.updatedValue ?: [NSNull null]};
}

static NSString *PPMEventText(NSDictionary *event) {
    NSString *kind = [event[@"kind"] isKindOfClass:[NSString class]] ? event[@"kind"] : @"CHANGED";
    NSString *key = [event[@"path"] isKindOfClass:[NSString class]] ? event[@"path"] : @"/";
    id oldValue = event[@"old"] == [NSNull null] ? nil : event[@"old"];
    id updatedValue = event[@"new"] == [NSNull null] ? nil : event[@"new"];
    NSString *before = oldValue ? PPMFormatValue(oldValue) : @"";
    NSString *after = updatedValue ? PPMFormatValue(updatedValue) : @"";
    if ([kind isEqualToString:@"ADDED"]) return [NSString stringWithFormat:@"ADDED %@ = %@", key, after];
    if ([kind isEqualToString:@"REMOVED"]) return [NSString stringWithFormat:@"REMOVED %@ (was %@)", key, before];
    return [NSString stringWithFormat:@"CHANGED %@\nOLD: %@\nNEW: %@", key, before, after];
}

@interface PPMInsetLabel : UILabel
@property (nonatomic, assign) UIEdgeInsets textInsets;
@end

@implementation PPMInsetLabel
- (instancetype)init {
    self = [super init];
    if (self) {
        _textInsets = UIEdgeInsetsMake(7, 8, 7, 8);
        self.numberOfLines = 0;
        self.font = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular];
        self.layer.cornerRadius = 6;
        self.layer.masksToBounds = YES;
    }
    return self;
}
- (void)drawTextInRect:(CGRect)rect {
    [super drawTextInRect:UIEdgeInsetsInsetRect(rect, self.textInsets)];
}
- (CGSize)sizeThatFits:(CGSize)size {
    UIEdgeInsets insets = self.textInsets;
    CGSize available = CGSizeMake(MAX(0, size.width - insets.left - insets.right), CGFLOAT_MAX);
    CGSize fitted = [super sizeThatFits:available];
    return CGSizeMake(fitted.width + insets.left + insets.right,
                      fitted.height + insets.top + insets.bottom);
}
- (CGSize)intrinsicContentSize {
    CGSize size = [super intrinsicContentSize];
    UIEdgeInsets insets = self.textInsets;
    return CGSizeMake(size.width + insets.left + insets.right,
                      size.height + insets.top + insets.bottom);
}
@end

@interface PPMEventCell : UITableViewCell
@property (nonatomic, strong) UILabel *headerLabel;
@property (nonatomic, strong) UILabel *pathLabel;
@property (nonatomic, strong) PPMInsetLabel *oldLabel;
@property (nonatomic, strong) PPMInsetLabel *newLabel;
- (void)configureWithEvent:(NSDictionary *)event time:(NSString *)time;
@end

@implementation PPMEventCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (!self) return nil;
    self.selectionStyle = UITableViewCellSelectionStyleNone;

    UIStackView *stack = [UIStackView new];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 6;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView addSubview:stack];

    _headerLabel = [UILabel new];
    _headerLabel.font = [UIFont monospacedSystemFontOfSize:10 weight:UIFontWeightBold];
    [stack addArrangedSubview:_headerLabel];

    _pathLabel = [UILabel new];
    _pathLabel.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightSemibold];
    _pathLabel.numberOfLines = 0;
    [stack addArrangedSubview:_pathLabel];

    _oldLabel = [PPMInsetLabel new];
    _oldLabel.backgroundColor = [[UIColor systemRedColor] colorWithAlphaComponent:0.10];
    [stack addArrangedSubview:_oldLabel];

    _newLabel = [PPMInsetLabel new];
    _newLabel.backgroundColor = [[UIColor systemGreenColor] colorWithAlphaComponent:0.12];
    [stack addArrangedSubview:_newLabel];

    [NSLayoutConstraint activateConstraints:@[
        [stack.topAnchor constraintEqualToAnchor:self.contentView.topAnchor constant:10],
        [stack.leadingAnchor constraintEqualToAnchor:self.contentView.leadingAnchor constant:14],
        [stack.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor constant:-14],
        [stack.bottomAnchor constraintEqualToAnchor:self.contentView.bottomAnchor constant:-10],
    ]];
    return self;
}

- (void)configureWithEvent:(NSDictionary *)event time:(NSString *)time {
    NSString *kind = event[@"kind"] ?: @"CHANGED";
    UIColor *kindColor = [kind isEqualToString:@"ADDED"] ? [UIColor systemGreenColor] :
        [kind isEqualToString:@"REMOVED"] ? [UIColor systemRedColor] : [UIColor systemOrangeColor];
    self.headerLabel.text = [NSString stringWithFormat:@"%@  ·  %@", kind, time];
    self.headerLabel.textColor = kindColor;
    self.pathLabel.text = event[@"path"] ?: @"/";

    id oldValue = event[@"old"] == [NSNull null] ? nil : event[@"old"];
    id newValue = event[@"new"] == [NSNull null] ? nil : event[@"new"];
    self.oldLabel.hidden = oldValue == nil;
    self.newLabel.hidden = newValue == nil;

    UIFont *caption = [UIFont monospacedSystemFontOfSize:10 weight:UIFontWeightBold];
    UIFont *body = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightRegular];
    if (oldValue) {
        NSMutableAttributedString *text = [[NSMutableAttributedString alloc]
            initWithString:@"OLD\n" attributes:@{NSFontAttributeName: caption,
            NSForegroundColorAttributeName: [UIColor systemRedColor]}];
        [text appendAttributedString:[[NSAttributedString alloc]
            initWithString:PPMFormatValue(oldValue) attributes:@{NSFontAttributeName: body,
            NSForegroundColorAttributeName: [UIColor labelColor]}]];
        self.oldLabel.attributedText = text;
    }
    if (newValue) {
        NSString *captionText = [kind isEqualToString:@"ADDED"] ? @"NEW\n" : @"NEW\n";
        NSMutableAttributedString *text = [[NSMutableAttributedString alloc]
            initWithString:captionText attributes:@{NSFontAttributeName: caption,
            NSForegroundColorAttributeName: [UIColor systemGreenColor]}];
        [text appendAttributedString:[[NSAttributedString alloc]
            initWithString:PPMFormatValue(newValue) attributes:@{NSFontAttributeName: body,
            NSForegroundColorAttributeName: [UIColor labelColor]}]];
        self.newLabel.attributedText = text;
    }
}

@end

@interface PPMViewController () <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITextField *pathField;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UIButton *recordButton;
@property (nonatomic, strong) UIButton *pauseButton;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray<NSDictionary *> *events;
@property (nonatomic, copy, nullable) NSString *currentPath;
@property (nonatomic, assign) BOOL recording;
@property (nonatomic, assign) BOOL paused;
@property (nonatomic, assign) BOOL importedCopy;
@property (nonatomic, strong) NSTimer *refreshTimer;
@property (nonatomic, assign) unsigned long long logOffset;
@property (nonatomic, assign) BOOL backgroundMode;
@property (nonatomic, strong, nullable) id directSnapshot;
@property (nonatomic, strong, nullable) NSData *directLastData;
@end

@implementation PPMViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"PlistPulse";
    self.view.backgroundColor = [UIColor systemBackgroundColor];
    self.events = [NSMutableArray array];
    [self buildInterface];
    self.refreshTimer = [NSTimer scheduledTimerWithTimeInterval:0.25 target:self
        selector:@selector(refreshBackgroundLog) userInfo:nil repeats:YES];
    [self refreshBackgroundStatus];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self refreshBackgroundStatus];
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleDefault;
}

- (void)buildInterface {
    UIStackView *content = [UIStackView new];
    content.axis = UILayoutConstraintAxisVertical;
    content.spacing = 10;
    content.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:content];

    UILabel *heading = [UILabel new];
    heading.text = @"LIVE PLIST MONITOR";
    heading.font = [UIFont boldSystemFontOfSize:13];
    heading.textColor = [UIColor secondaryLabelColor];
    [content addArrangedSubview:heading];

    self.pathField = [UITextField new];
    self.pathField.placeholder = @"/path/to/file.plist";
    self.pathField.borderStyle = UITextBorderStyleRoundedRect;
    self.pathField.font = [UIFont monospacedSystemFontOfSize:14 weight:UIFontWeightRegular];
    self.pathField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.pathField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.pathField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.pathField.spellCheckingType = UITextSpellCheckingTypeNo;
    self.pathField.returnKeyType = UIReturnKeyDone;
    [self.pathField addTarget:self action:@selector(endEditing) forControlEvents:UIControlEventEditingDidEndOnExit];
    [content addArrangedSubview:self.pathField];

    UIButton *paste = [self buttonWithTitle:@"Paste path from Filza" color:[UIColor systemGrayColor]
        action:@selector(pasteFilzaPath)];
    [content addArrangedSubview:paste];

    self.recordButton = [self buttonWithTitle:@"Start monitoring" color:[UIColor systemGreenColor]
        action:@selector(toggleRecording)];
    [content addArrangedSubview:self.recordButton];

    UIStackView *tools = [UIStackView new];
    tools.axis = UILayoutConstraintAxisHorizontal;
    tools.spacing = 8;
    tools.distribution = UIStackViewDistributionFillEqually;
    self.pauseButton = [self buttonWithTitle:@"Pause log" color:[UIColor systemOrangeColor] action:@selector(togglePause)];
    [tools addArrangedSubview:self.pauseButton];
    [tools addArrangedSubview:[self buttonWithTitle:@"Clear" color:[UIColor systemGrayColor] action:@selector(clearLog)]];
    [tools addArrangedSubview:[self buttonWithTitle:@"Share" color:[UIColor systemIndigoColor] action:@selector(shareLog)]];
    [content addArrangedSubview:tools];

    self.statusLabel = [UILabel new];
    self.statusLabel.numberOfLines = 3;
    self.statusLabel.font = [UIFont systemFontOfSize:12];
    self.statusLabel.textColor = [UIColor secondaryLabelColor];
    self.statusLabel.text = @"Paste a full plist path from Filza to begin.";
    [content addArrangedSubview:self.statusLabel];

    self.tableView = [UITableView new];
    self.tableView.translatesAutoresizingMaskIntoConstraints = NO;
    self.tableView.estimatedRowHeight = 74;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeInteractive;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:self.tableView];

    UILayoutGuide *safe = self.view.safeAreaLayoutGuide;
    [NSLayoutConstraint activateConstraints:@[
        [content.topAnchor constraintEqualToAnchor:safe.topAnchor constant:12],
        [content.leadingAnchor constraintEqualToAnchor:safe.leadingAnchor constant:16],
        [content.trailingAnchor constraintEqualToAnchor:safe.trailingAnchor constant:-16],
        [self.tableView.topAnchor constraintEqualToAnchor:content.bottomAnchor constant:12],
        [self.tableView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.tableView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.tableView.bottomAnchor constraintEqualToAnchor:safe.bottomAnchor],
    ]];
}

- (UIButton *)buttonWithTitle:(NSString *)title color:(UIColor *)color action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    [button setTitle:title forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    button.titleLabel.adjustsFontSizeToFitWidth = YES;
    button.titleLabel.minimumScaleFactor = 0.8;
    [button setTitleColor:color forState:UIControlStateNormal];
    button.layer.borderWidth = 1;
    button.layer.borderColor = color.CGColor;
    button.layer.cornerRadius = 8;
    [button.heightAnchor constraintEqualToConstant:40].active = YES;
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}

- (void)endEditing {
    [self.pathField resignFirstResponder];
}

- (void)pasteFilzaPath {
    NSString *clipboard = UIPasteboard.generalPasteboard.string;
    if (clipboard.length == 0) {
        [self showMessage:@"Copy the plist's full path in Filza first, then tap Paste path from Filza." title:@"No path on clipboard"];
        return;
    }
    self.pathField.text = clipboard;
    [self openPath:clipboard];
}

- (void)openPath:(NSString *)path {
    NSString *clean = [path stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (![clean hasPrefix:@"/"]) {
        [self showMessage:@"Paste the absolute path, for example /var/mobile/Library/Preferences/example.plist" title:@"Invalid path"];
        return;
    }
    [self stopMonitoring];
    self.pathField.text = clean;
    self.importedCopy = [clean containsString:@"/Documents/Inbox/"];
    [self startMonitoring:clean];
}

- (void)toggleRecording {
    if (self.recording) {
        [self stopMonitoring];
        [self updateStatus];
        return;
    }
    NSString *path = [self.pathField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    self.importedCopy = [path containsString:@"/Documents/Inbox/"];
    [self startMonitoring:path];
}

- (void)startMonitoring:(NSString *)path {
    if (![path hasPrefix:@"/"]) {
        [self showMessage:@"Enter an absolute plist path." title:@"Invalid path"];
        return;
    }
    BOOL isDirectory = NO;
    if (![[NSFileManager defaultManager] fileExistsAtPath:path isDirectory:&isDirectory] || isDirectory) {
        [self showMessage:@"The file does not exist or is not accessible to PlistPulse." title:@"Cannot access plist"];
        return;
    }
    if ([PPMDiffEngine readPlistAtPath:path] == nil) {
        [self showMessage:@"The file is empty or is not a valid plist. Monitoring starts only when its current contents can be read." title:@"Invalid plist"];
        return;
    }

    self.logOffset = 0;
    if (self.importedCopy) {
        self.currentPath = path;
        self.recording = NO;
        self.statusLabel.text = [NSString stringWithFormat:@"IMPORTED COPY — NOT LIVE\n%@\nFilza imported a copy. Copy the original plist's full path in Filza, then paste it here.", path];
        [self showMessage:@"For live changes, use Filza > plist > More > Copy path, then paste the original path. The imported copy can only be read as a static snapshot." title:@"Imported copy"];
        return;
    }

    self.currentPath = path;
    self.paused = NO;
    [self.events removeAllObjects];
    [self.tableView reloadData];
    self.logOffset = 0;
    self.backgroundMode = NO;

    if (!PPMBackgroundRecorderAvailable()) PPMTryLoadRecorder();

    if (PPMBackgroundRecorderAvailable()) {
        NSError *error = nil;
        if (PPMConfigureBackgroundRecording(path, &error)) {
            [[NSFileManager defaultManager] removeItemAtPath:PPMLogPath() error:nil];
            self.backgroundMode = YES;
            self.recording = YES;
            [self updateStatus];
            return;
        }
    }

    // Fallback: monitor directly while the app is open.
    self.recording = YES;
    self.directSnapshot = [PPMDiffEngine readPlistAtPath:path];
    self.directLastData = [NSData dataWithContentsOfFile:path];
    [self updateStatus];
}

- (void)stopMonitoring {
    BOOL wasRecording = self.recording;
    self.recording = NO;
    self.paused = NO;
    if (wasRecording && self.backgroundMode && !self.importedCopy) {
        PPMConfigureBackgroundRecording(nil, nil);
        for (NSDictionary *event in PPMReadNewEvents(&_logOffset)) [self appendEvent:event];
    }
    self.backgroundMode = NO;
    self.directSnapshot = nil;
    self.directLastData = nil;
    [self updateStatus];
}

- (void)updateStatus {
    [self.recordButton setTitle:self.recording ? @"Stop monitoring" : @"Start monitoring" forState:UIControlStateNormal];
    UIColor *color = self.recording ? [UIColor systemRedColor] : [UIColor systemGreenColor];
    [self.recordButton setTitleColor:color forState:UIControlStateNormal];
    self.recordButton.layer.borderColor = color.CGColor;
    self.pauseButton.enabled = self.recording;
    if (!self.recording) {
        self.statusLabel.text = @"Stopped. Paste a full plist path from Filza to begin.";
        return;
    }
    NSString *mode = self.paused ? @"LOG PAUSED" : @"LIVE";
    if (!self.backgroundMode) {
        self.statusLabel.text = [NSString stringWithFormat:@"%@  •  %@\nFOREGROUND ONLY — recorder daemon not running.\nLoad it once as root: launchctl bootstrap system /Library/LaunchDaemons/dev.plistpulse.recorder.plist", mode, self.currentPath];
        return;
    }
    self.statusLabel.text = [NSString stringWithFormat:@"%@  •  %@\n%@\nUse another app, then return to review saved changes.", mode, self.currentPath, PPMBackgroundStatus()];
}

- (void)togglePause {
    if (!self.recording) return;
    self.paused = !self.paused;
    [self.pauseButton setTitle:self.paused ? @"Resume log" : @"Pause log" forState:UIControlStateNormal];
    [self updateStatus];
}

- (void)clearLog {
    [self.events removeAllObjects];
    [self.tableView reloadData];
    [[NSFileManager defaultManager] removeItemAtPath:PPMLogPath() error:nil];
    self.logOffset = 0;
    if (self.recording && !self.backgroundMode) {
        self.directLastData = [NSData dataWithContentsOfFile:self.currentPath];
        self.directSnapshot = [PPMDiffEngine readPlistAtPath:self.currentPath];
    }
}

- (void)shareLog {
    if (self.events.count == 0) {
        [self showMessage:@"There are no changes to export yet." title:@"Log is empty"];
        return;
    }
    NSMutableArray *lines = [NSMutableArray arrayWithObject:[NSString stringWithFormat:@"PlistPulse — %@", self.currentPath ?: @""]];
    for (NSDictionary *event in self.events) {
        [lines addObject:[NSString stringWithFormat:@"%@  %@", [PPMTimeFormatter() stringFromDate:PPMEventDate(event)], PPMEventText(event)]];
    }
    NSString *path = [NSTemporaryDirectory() stringByAppendingPathComponent:@"PlistPulse-log.txt"];
    [[lines componentsJoinedByString:@"\n"] writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    UIActivityViewController *activity = [[UIActivityViewController alloc] initWithActivityItems:@[[NSURL fileURLWithPath:path]] applicationActivities:nil];
    activity.popoverPresentationController.sourceView = self.view;
    [self presentViewController:activity animated:YES completion:nil];
}

- (void)refreshBackgroundLog {
    if (!self.recording || self.paused) return;
    if (!self.backgroundMode) {
        [self checkDirect];
        return;
    }
    for (NSDictionary *event in PPMReadNewEvents(&_logOffset)) [self appendEvent:event];
}

- (void)checkDirect {
    if (self.currentPath.length == 0) return;
    NSData *data = [NSData dataWithContentsOfFile:self.currentPath];
    if (data.length == 0 || [data isEqualToData:self.directLastData]) return;
    id root = [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListImmutable format:nil error:nil];
    if (root == nil) return;
    self.directLastData = data;
    if (self.directSnapshot != nil && [self.directSnapshot isEqual:root]) return;
    NSArray<PPMChange *> *changes = [PPMDiffEngine changesFrom:self.directSnapshot to:root];
    self.directSnapshot = root;
    for (PPMChange *change in changes) [self appendEvent:PPMEvent(change)];
}

- (void)appendEvent:(NSDictionary *)event {
    if (self.paused) return;
    if (self.events.count >= 1000) [self.events removeObjectAtIndex:0];
    [self.events addObject:event];
    [self.tableView reloadData];
    if (self.events.count > 0) {
        [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.events.count - 1 inSection:0]
            atScrollPosition:UITableViewScrollPositionBottom animated:NO];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.events.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"event";
    PPMEventCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[PPMEventCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    NSDictionary *event = self.events[indexPath.row];
    [cell configureWithEvent:event time:[PPMTimeFormatter() stringFromDate:PPMEventDate(event)]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *event = self.events[indexPath.row];
    NSString *text = [NSString stringWithFormat:@"%@\n%@", [PPMTimeFormatter() stringFromDate:PPMEventDate(event)], PPMEventText(event)];
    UIPasteboard.generalPasteboard.string = text;
    [self showMessage:@"The event was copied to the clipboard." title:@"Copied"];
}

- (void)refreshBackgroundStatus {
    if (self.recording) [self updateStatus];
}

- (void)showMessage:(NSString *)message title:(NSString *)title {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message
        preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
