#import <UIKit/UIKit.h>
#import "PPMAppDelegate.h"

int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PPMAppDelegate class]));
    }
}
