"""Host-side regression tests for the documented recursive diff behavior.

These are algorithm-level tests for Windows; the iOS app is separately compiled
with Theos. Run with: python -m unittest discover -s Tests -v
"""
import unittest

ADDED, REMOVED, CHANGED = "ADDED", "REMOVED", "CHANGED"


def walk(old, new, path=""):
    if old == new and type(old) is type(new):
        return []
    if isinstance(old, dict) and isinstance(new, dict):
        result = []
        for key in sorted(set(old) | set(new), key=str):
            child_path = f"{path}/{key}"
            if key not in old:
                result.append((ADDED, child_path, None, new[key]))
            elif key not in new:
                result.append((REMOVED, child_path, old[key], None))
            else:
                result.extend(walk(old[key], new[key], child_path))
        return result
    if isinstance(old, list) and isinstance(new, list):
        result = []
        for index in range(min(len(old), len(new))):
            result.extend(walk(old[index], new[index], f"{path}/{index}"))
        for index in range(len(old), len(new)):
            result.append((ADDED, f"{path}/{index}", None, new[index]))
        for index in range(len(new), len(old)):
            result.append((REMOVED, f"{path}/{index}", old[index], None))
        return result
    if old is None:
        return [(ADDED, path or "/", None, new)]
    if new is None:
        return [(REMOVED, path or "/", old, None)]
    return [(CHANGED, path or "/", old, new)]


class DiffEngineTests(unittest.TestCase):
    def test_unchanged(self):
        self.assertEqual(walk({"enabled": True}, {"enabled": True}), [])

    def test_nested_change(self):
        changes = walk({"general": {"enabled": False}}, {"general": {"enabled": True}})
        self.assertEqual(changes, [(CHANGED, "/general/enabled", False, True)])

    def test_added_and_removed(self):
        changes = walk({"old": 1}, {"new": "hello"})
        self.assertEqual(changes, [(ADDED, "/new", None, "hello"), (REMOVED, "/old", 1, None)])

    def test_array_edits(self):
        changes = walk({"items": [1, 2, 3]}, {"items": [1, 4]})
        self.assertIn((CHANGED, "/items/1", 2, 4), changes)
        self.assertIn((REMOVED, "/items/2", 3, None), changes)

    def test_false_and_zero_are_not_absent(self):
        self.assertEqual(walk({"value": False}, {}), [(REMOVED, "/value", False, None)])
        self.assertEqual(walk({}, {"value": 0}), [(ADDED, "/value", None, 0)])

    def test_no_duplicate_events_for_equal_snapshot(self):
        original = {"screen": "home", "values": [1, 2]}
        self.assertEqual(walk(original, original.copy()), [])


if __name__ == "__main__":
    unittest.main()
